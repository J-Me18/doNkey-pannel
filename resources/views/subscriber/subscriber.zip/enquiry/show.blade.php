@extends('layouts.submaster')
@section('content')
<div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-10">
              <div class="card card-fill timeline">
                <div class="card-header">
                  <h5 class="text-center "><strong  class="text-danger">ENQUIRY DETAILS</strong></h2>
                </div>
                <div class="card-body">
                  <table class="table table-striped  table-bordered ">

                <tbody>
                  <tr class="table-success">
                        <td class="text-center"> <strong>Name </strong></td>
                        <td>{{$enquiry->name }}</td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"><strong> Email ID</strong></td>
                    <td> {{ $enquiry->mailId }}</td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"><strong> Mobile</strong> </td>
                    <td> {{ $enquiry->mobile }}</td>

                  </tr>
                   <tr class="table-success">
                    <td class="text-center"> <strong>Area </strong></td>
                    <td> {{ $enquiry->area }}</td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"><strong> Category </strong></td>
                    <td> {{ $enquiry->category }}</td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"><strong> Pincode</strong>  </td>
                    <td>


                      @foreach($pincode as $pin)


                      @if(in_array($pin->id, $enquiry->pincode))
                      {{ $pin->pincode }}
                      @endif
                     @endforeach



                    </td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"><strong> Favourite </strong></td>
                    <td> @if($enquiry->ficon == 1) Yes @else No @endif</td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"> <strong>Submitted On </strong></td>
                    <td>{{ $enquiry->created_at}}</td>

                  </tr>
                  <tr class="table-success">
                    <td class="text-center"><strong> Description</strong> </td>
                    <td> {{ $enquiry->description }}</td>

                  </tr>

                </tbody>

                  </table>







                </div> <!-- / .card-body -->
              </div> <!-- / .card -->
            </div> <!-- .col-12 -->
          </div> <!-- .row -->
        </div>
        @endsection
        @section('scripts')
        @endsection
